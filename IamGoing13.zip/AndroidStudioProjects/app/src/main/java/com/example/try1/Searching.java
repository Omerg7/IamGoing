package com.example.try1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TimePicker;
import android.app.TimePickerDialog;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;

public class Searching extends AppCompatActivity implements View.OnClickListener {

    AutoCompleteTextView searching_from, searching_to;
   ImageButton searching_ride, advanced_search;
    int day, month, hour, minute;
    ListView lv_searching;
    FirebaseDatabase database;
    DatabaseReference myref1;
    ArrayList<Ride> arrAllRides;
    String savedText;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_searching);

        arrAllRides = new ArrayList<>();
        database = FirebaseDatabase.getInstance();
        myref1 = database.getReference();

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, Places);
        AutoCompleteTextView searching_from = (AutoCompleteTextView) findViewById(R.id.searching_from);
        searching_from.setAdapter(adapter);

        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, Places);
        AutoCompleteTextView searching_to = (AutoCompleteTextView) findViewById(R.id.searching_to);
        searching_to.setAdapter(adapter);

        searching_ride = (ImageButton) findViewById(R.id.searching_ride);
        advanced_search = (ImageButton) findViewById(R.id.advanced_search);
        lv_searching = (ListView) findViewById(R.id.lv_searching);


        searching_ride.setOnClickListener(this);
        advanced_search.setOnClickListener(this);
        Calendar israelTime = new GregorianCalendar(TimeZone.getTimeZone("GMT+2"));
        hour = israelTime.get(Calendar.HOUR_OF_DAY);
        minute = israelTime.get(Calendar.MINUTE);
        day = israelTime.get(Calendar.DAY_OF_MONTH);
        month = israelTime.get(Calendar.MONTH) + 1;






        Query q = myref1.child("Rides").orderByValue();
        q.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dst : snapshot.getChildren()) {
                    Ride r = dst.getValue(Ride.class);
                    arrAllRides.add(r);
                }
                RidesAdapter myRideAdapter = new RidesAdapter(Searching.this, 0, 0,arrAllRides);
                lv_searching.setAdapter(myRideAdapter);
                lv_searching.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                        Toast.makeText(Searching.this, "Line Number:"+ i, Toast.LENGTH_LONG).show();

                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });







    }

    private static final String[] Places = new String[]{
            "יובלים", "שכניה"
    };


    @Override
    public void onClick(View view) {
        int SearchListLength;
        
        if (view == searching_ride){
            SearchListLength= arrAllRides.size();
            String search_searchingfrom = searching_from.getText().toString();


            for (int i=0; i <SearchListLength; i++){
                if (arrAllRides.get(i).getGoingFrom().equals(search_searchingfrom)){
                    Toast.makeText(Searching.this, "exits", Toast.LENGTH_LONG).show();

                }
            }

        }
    if (view == advanced_search){

    }

    }
}









