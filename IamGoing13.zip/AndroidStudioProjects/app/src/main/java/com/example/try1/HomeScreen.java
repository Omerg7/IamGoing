package com.example.try1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class HomeScreen extends AppCompatActivity implements View.OnClickListener {
    Button btn_driving, btn_searching;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);

        btn_driving = (Button)findViewById(R.id.btn_driving);
        btn_driving.setOnClickListener(this);
        btn_searching = (Button)findViewById(R.id.btn_searching);
        btn_searching.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (view == btn_searching){
            Intent intent_Searching = new Intent(HomeScreen.this, Searching.class);
            startActivity(intent_Searching);
        }
        if(view == btn_driving){
            Intent intent_Driving = new Intent(HomeScreen.this, Driving.class);
            startActivity(intent_Driving);
        }

    }
}