package com.example.try1;

import java.util.ArrayList;

public class User{
    private String name, pass;
    private Ride ride;

    public User() {
    }

    public User(String name, String pass) {
        this.name = name;
        this.pass = pass;
    }

    public String getName() {
    return name;
}
    public String getPass() {
        return pass;
    }

    public void setName(String name) {
        this.name = name;
    }
    public void setPass(String pass) {
        this.pass = pass;
    }

    public Ride getRide() {
        return ride;
    }

    public void setRide(Ride ride) {
        this.ride = ride;
    }
}
